import { createContext } from 'react'
import { useSelector } from 'react-redux';
import { productsSelector } from '../Components/reducerSlice';

export const ProductsContext = createContext();
const LimitProductsContext = (props) => {
    const limitProducts = useSelector((state) => productsSelector.selectAll(state));
    return (
        <ProductsContext.Provider value={limitProducts}>
            {props.children}
        </ProductsContext.Provider>
    );
}

export default LimitProductsContext;

// export const context = ()=>{
//     const limitProducts = useSelector((state)=>productsSelector.selectAll(state));
//     return React.createContext({
//         limitedProducts : limitProducts,
//     });
// }