import React from 'react'
const style = {
    backgroundColor: "#e3f2fd"
}
const Header = () => {
    return (
        <nav className="navbar navbar-expand-lg fixed-top" style={style}>
            <div className="container-fluid">
                <a className="navbar-brand" href="#">E-Commerce</a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                        <li className="nav-item">
                            <a className="nav-link active" aria-current="page" href="#">Home</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" href="#">Products</a>
                        </li>
                        <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Categories
                            </a>
                            <ul className="dropdown-menu" aria-labelledby="navbarDropdown" style={{ backgroundColor: "#e3f2fd", border: "none" }}>
                                <li><a className="dropdown-item" href="#">Electronics</a></li>
                                <li><a className="dropdown-item" href="#">Jewelery</a></li>
                                <li><a className="dropdown-item" href="#">Men's clothing</a></li>
                                <li><a className="dropdown-item" href="#">Women's clothing</a></li>
                            </ul>
                        </li>
                    </ul>
                    <form className="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3">
                        <input type="search" className="form-control form-control-dark" placeholder="Search..." aria-label="Search" />
                    </form>
                    <div className="text-end">
                        <button type="button" className="btn btn-outline-primary me-2">Login</button>
                        <button type="button" className="btn btn-warning">Sign-up</button>
                    </div>
                </div>
            </div>
        </nav>
    )
}

export default Header