import React from 'react'
import './assets/style.css'
import Trending from './ProductSections/Trending'
import Categories from './ProductSections/Categories'
import Product from './ProductSections/Product';

const Products = (limitpro) => {
  // console.log(limitpro);
  return (
    <React.Fragment>
        <Trending />
        <Categories />
        <Product />
    </React.Fragment>
  )
}

export default Products;