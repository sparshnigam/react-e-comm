import React, { useContext } from 'react'

const Product = () => {
  return (
    <div className='container'>
      <h2>From the <b>Shop</b></h2>
      {/* <p className="font-italic text-muted mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.</p> */}

      <div className="row pb-5 mb-4">
        <div className="col-lg-3 col-md-6 mb-4 mb-lg-0">
          {/* <!-- Card--> */}
          <div className="rounded shadow-sm border-0">
            <div className="card-body p-4"><img src="https://bootstrapious.com/i/snippets/sn-cards/shoes-1_gthops.jpg" alt="" className="img-fluid d-block mx-auto mb-3" />
              <h5> <a href="#" className="text-dark">Awesome product</a></h5>
              <p className="small text-muted font-italic">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              <ul className="list-inline small">
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star-o text-success"></i></li>
              </ul>
            </div>
          </div>
        </div>

        <div className="col-lg-3 col-md-6 mb-4 mb-lg-0">
          {/* <!-- Card--> */}
          <div className="rounded shadow-sm border-0">
            <div className="card-body p-4"><img src="https://bootstrapious.com/i/snippets/sn-cards/shoes-2_g4qame.jpg" alt="" className="img-fluid d-block mx-auto mb-3" />
              <h5> <a href="#" className="text-dark">Awesome product</a></h5>
              <p className="small text-muted font-italic">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              <ul className="list-inline small">
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star-o text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star-o text-success"></i></li>
              </ul>
            </div>
          </div>
        </div>

        <div className="col-lg-3 col-md-6 mb-4 mb-lg-0">
          {/* <!-- Card--> */}
          <div className="rounded shadow-sm border-0">
            <div className="card-body p-4"><img src="https://bootstrapious.com/i/snippets/sn-cards/shoes-3_rk25rt.jpg" alt="" className="img-fluid d-block mx-auto mb-3" />
              <h5> <a href="#" className="text-dark">Awesome product</a></h5>
              <p className="small text-muted font-italic">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              <ul className="list-inline small">
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
              </ul>
            </div>
          </div>
        </div>

        <div className="col-lg-3 col-md-6 mb-4 mb-lg-0">
          {/* <!-- Card--> */}
          <div className="rounded shadow-sm border-0">
            <div className="card-body p-4"><img src="https://bootstrapious.com/i/snippets/sn-cards/shoes-4_vgfjy9.jpg" alt="" className="img-fluid d-block mx-auto mb-3" />
              <h5> <a href="#" className="text-dark">Awesome product</a></h5>
              <p className="small text-muted font-italic">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
              <ul className="list-inline small">
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star text-success"></i></li>
                <li className="list-inline-item m-0"><i className="fa fa-star-o text-success"></i></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Product;