import productsReducer from "./reducerSlice";
import { configureStore } from "@reduxjs/toolkit";
import thunk from "redux-thunk";

const store = configureStore({
    reducer: {products: productsReducer},
    middleware: [thunk],
});

export default store;