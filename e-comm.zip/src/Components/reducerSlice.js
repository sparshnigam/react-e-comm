import { createAsyncThunk, createEntityAdapter, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

export const fetchLimitProducts = createAsyncThunk('limitProducts', async ()=>{
    const response = await axios.get('https://fakestoreapi.com/products?limit=12');
    return response.data;
})
export const fetchCategories = createAsyncThunk('productCategories', async ()=>{
    const response = await axios.get('https://fakestoreapi.com/products/categories');
    return response.data;
})

const productsAdapter = createEntityAdapter({
    selectId: (products) => products.id,
});
// const categoriesAdapter = createEntityAdapter({
//     selectId: (categories) => categories.id,
// });

const productsSlice = createSlice({
    name: "products",
    initialState: productsAdapter.getInitialState(),
    reducers: {},
    extraReducers: (builder)=>{
        builder
        .addCase(fetchLimitProducts.pending,(state)=>{
            state.loading = true;
            state.error = null;
        })
        .addCase(fetchLimitProducts.fulfilled,(state,action)=>{
            state.loading = false;
            state.error = null;
            productsAdapter.setAll(state,action.payload);
        })
        .addCase(fetchLimitProducts.rejected,(state,action)=>{
            state.loading = false;
            state.error = action.error;
        })
        .addCase(fetchCategories.pending,(state)=>{
            state.loading = true;
            state.categories = {};
            state.error = null;
        })
        .addCase(fetchCategories.fulfilled,(state,action)=>{
            state.loading = false;
            state.error = null;
            state.categories = action.payload;
            // categoriesAdapter.setAll(state.categories,{categories: action.payload});
        })
        .addCase(fetchCategories.rejected,(state,action)=>{
            state.loading = false;
            state.error = action.error;
        })
        .addDefaultCase((state)=>{
            return state;
        })
    },
});

export const productsSelector = productsAdapter.getSelectors((state)=>state.products);
// export const categoriesSelector = categoriesAdapter.getSelectors((state)=>state.products);
export default productsSlice.reducer;