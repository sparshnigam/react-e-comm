import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Banner } from './Components/Banner';
import Products from './Components/Products';
import Footer from './utilities/Footer';
import Header from './utilities/Header';
import { fetchCategories, fetchLimitProducts, productsSelector } from './Components/reducerSlice';

const App = () => {

    const dispatch = useDispatch();
    
    const status = useSelector((state)=>state);
    // const limitProducts = useSelector((state)=>productsSelector.selectAll(state));
    
    useEffect(()=>{
        dispatch(fetchLimitProducts());
        dispatch(fetchCategories());
    },[]);

    const RenderProducts = ()=>{
        if(status.products.loading){
            return <p>Loading...</p>;
        }else{
            return (
                <React.Fragment>
                    <Header />
                    <Banner />
                    {/* <Products limitpro={limitProducts} /> */}
                    <Products />
                    <Footer />
                </React.Fragment>
            );
        }
    };
    
  return (
    <div>
        <RenderProducts />
    </div>
  )
}

export default App