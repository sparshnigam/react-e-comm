import React from 'react';
import ReactDOM from 'react-dom';
// import { ReactDOM } from 'react';
import './index.css';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';
import App from './App';
import { Provider } from 'react-redux';
import store from './Components/store';
import LimitedProductsContext from './context/LimitProductContext';

const root = document.getElementById('root');
ReactDOM.render(
  <React.StrictMode>
    <Provider store={store}>
      <LimitedProductsContext>
        <App />
      </LimitedProductsContext>
    </Provider>
  </React.StrictMode>,
  root
);

reportWebVitals();
